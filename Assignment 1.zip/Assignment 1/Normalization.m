function Result = Normalization(features)
    for j=2:length(features(1,:))
        if max(abs(features(:,j)))~=0
            features(:,j)=(features(:,j)-mean((features(:,j))))./std(features(:,j));
        end
    end
    Result=features;
end

