function result=Cost_func(X,y,theta)
    
    m=length(y);
    h=X*theta;
    result=1/(2*m)*sum((h-y).^2);
    
end