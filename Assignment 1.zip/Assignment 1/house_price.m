clear all;
clc;
dataArray=xlsread('house_data_complete.csv');
alpha=0.0001;
i_ts=floor(length(dataArray)*.6);
i_cv=floor(length(dataArray)*.2);
training_price=dataArray(1:i_ts,3);
%Scalling price vector
training_price=training_price/mean(training_price);
features_training=dataArray(1:i_ts,4:21); 
features_training=[ones(i_ts,1),features_training];
features_training_2=getPolyFunc(dataArray(1:i_ts,4:21),2);
features_training_4=getPolyFunc(dataArray(1:i_ts,4:21),4);
features_training_20=getPolyFunc(dataArray(1:i_ts,4:21),20);
thetas=zeros(19,1);
%scalling features matrix
features_training=Normalization(features_training);
features_training_2=Normalization(features_training_2);
features_training_4=Normalization(features_training_4);
features_training_20=Normalization(features_training_20);

iterations=1000;
iterations_vec=1:1:iterations;

[thetas0,J_training]=Gradient_Descent(features_training,training_price,thetas,alpha,iterations);
thetas=zeros(length(features_training_2(1,:)),1);
[thetas2,J_training2]=Gradient_Descent(features_training_2,training_price,thetas,alpha,iterations);
thetas=zeros(length(features_training_4(1,:)),1);
[thetas4,J_training4]=Gradient_Descent(features_training_4,training_price,thetas,alpha,iterations);
thetas=zeros(length(features_training_20(1,:)),1);
[thetas20,J_training20]=Gradient_Descent(features_training_20,training_price,thetas,alpha,iterations);
subplot(1,2,1);
plot(iterations_vec,J_training);
hold on;
plot(iterations_vec,J_training2);
hold on;
plot(iterations_vec,J_training4);
hold on;
plot(iterations_vec,J_training20);
hold off;
legend('Degree 1','Degree 2','Degree 4','Degree 20');
xlabel('Number of Iterations');
ylabel('Mean square error');

%Normalized cross validation price
cv_price=dataArray(1+i_ts:i_ts+i_cv,3)/mean(dataArray(1+i_ts:i_ts+i_cv,3));

%Normalized cross validation features
features_cv=Normalization([ones(i_cv,1) dataArray(1+i_ts:i_ts+i_cv,4:21)]);
features_cv2=Normalization(getPolyFunc(dataArray(1+i_ts:i_ts+i_cv,4:21),2));
features_cv4=Normalization(getPolyFunc(dataArray(1+i_ts:i_ts+i_cv,4:21),4));
features_cv20=Normalization(getPolyFunc(dataArray(1+i_ts:i_ts+i_cv,4:21),20));

cv_Result=zeros(4,1);
cv_Result(1)=Cost_func(features_cv,cv_price,thetas0);
cv_Result(2)=Cost_func(features_cv2,cv_price,thetas2);
cv_Result(3)=Cost_func(features_cv4,cv_price,thetas4);
cv_Result(4)=Cost_func(features_cv20,cv_price,thetas20);

training_Result=zeros(4,1);
training_Result(1)=Cost_func(features_training,training_price,thetas0);
training_Result(2)=Cost_func(features_training_2,training_price,thetas2);
training_Result(3)=Cost_func(features_training_4,training_price,thetas4);
training_Result(4)=Cost_func(features_training_20,training_price,thetas20);
subplot(1,2,2);
plot(cv_Result);
hold on;
plot(training_Result);
hold off;
legend('Cross validation','training');
xlabel('Degree of Polynomial');
ylabel('Cost Function');

Normal_eq=inv(transpose(features_training)*features_training)*transpose(features_training)*training_price;