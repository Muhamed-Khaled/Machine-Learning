function Result =getPolyFunc(Function,degree)
    for i=1:degree
        if(i==1)
            Result=[ones(length(Function),1) Function];
        else
            Result=[Result Function.^i];
        end
    end
end

