function result=Cost_func(X,y,theta)
    
    m=length(y);
    h=sigmoid(X*theta);
    result=-(1/m)*sum(y.*log(h)+(1-y).* log(1-h));
    
end