function [theta,Js]=Gradient_Descent(X,y,theta,alpha,iterations)
    
    m=length(y);
    Js=zeros(iterations,1);
    for i=1:iterations
        hypothesis=sigmoid(X*theta);
        for j=1:length(theta)
            temp_theta=theta(j)-(alpha*(1/m)*sum((hypothesis-y).*X(:,j)));
            theta(j)=temp_theta;
        end
        Js(i)=Cost_func(X,y,theta);
    end
end