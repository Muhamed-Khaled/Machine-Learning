clc
clear 
close all

data = xlsread('house_prices_data_training_data.csv');

X = data(:,4:21);
[m n] = size(X);
X = Normalization(X);
 
 
[m n] = size(X);
Corr_x = corr(X);
x_cov=cov(X);
[U S V] =  svd(x_cov);

[S_row S_Column] = size(S);
eign_values = zeros(1,S_Column);
for i = 1:1:S_row
    eign_values(i) = sum(S(i,:));
end
%alpha = 0;


sum_eigenvalues = sum(eign_values);
for i = 1:1:n
    alpha = 1 - (sum(eign_values(1,1:i)) / sum_eigenvalues);
    if (alpha <= 0.001)
        k = i;
        break;
    end
    

end

R = U(:,1:k)' * X';
X_approx =  U(:,1:k) * R;

error = (1/m) *( sum(X_approx) - sum (R)).^2;
error = error';


% % K = 15;
% % size(X,2);
% % centroids = zeros(K,size(X,2));
% % 
% %  randidx = randperm(size(X,1));
% %  randidx(1:K);
% % centroids = X(randidx(1:K), :);
% % 
% % 
% % 
% % clust = zeros(size(X,1),15);
% % for i=1:15
% % clust(:,i) = kmeans(X,i,'emptyaction','singleton',...
% %         'replicate',5);
% % end
% % va = evalclusters(X,clust,'CalinskiHarabasz')
% 
% 
% % [m n] = size(X);
% % 
% %    cluster = 15; 
% %  randidx = randperm(size(X,1));
% % for clusters = 1:1:cluster
% %     centroids = zeros(clusters,n);
% %     
% %     %for itr = 1:1:iter
% %         % Random Initialization for the Centroids each Iteration
% %         
% %         centroids = X(randidx(1:clusters), :);
% % 
% %        %Clustering Assignment
% %         for i=1:m
% %             k = 1;
% %             min_dist = sum((X(i,:) - centroids(1,:)) .^ 2);
% %             for j=2:clusters
% %                 dist = sum((X(i,:) - centroids(j,:)) .^ 2);
% %                 if(dist < min_dist)
% %                     min_dist = dist;
% %                     k = j;
% %                 end
% %             end
% %             indices(i) = k;
% %         end
% %         
% %         %Moving the Centroids
% %         for k=1:1:clusters
% %             result = 0;
% %             count = 0;
% %             for i=1:1:m
% %                 if(indices(i) == k )
% %                 result = result + X(i,:);
% %                 count = count+1;
% %                 end
% %             end
% %          centroids(k,:) = (1/count) *result;
% %         end
% %         
% %         % Compute The cost function
% %         for i=1:1:m
% %             J_cost(1,i) =  sum(X(i,:) - centroids(indices(1,i),:))^2;
% %         end
% %         J = (1/m)*sum(J_cost);
% %         J_hist(1,clusters) = J; 
% % %         if(itr == 1 )
% % %             J_min = J;
% % %             centroids_min = centroids;
% % %             indices_min = indices;
% % %             itr_min = itr;
% % %         else
% % %             if(J_min > J)
% % %                 J_min = J;
% % %                 centroids_min = centroids;
% % %                 indices_min = indices;
% % %                 itr_min = itr;
% % %             end
% % %         end
% %             
% % 
% % 
% %     %end
% % %    J_history(1,clusters) = J_min;
% % end
% r0 = round(m*0.6);
% r1 = round(r0+(m*0.2));
% r2 = round(r1 + m*0.2);
% 
% x_train = X(1:r0 , :);
% [m_train n_train] = size(x_train);
% x_cv = X(r0+1:r1 , :);
% x_test = X(r1+1:end , :);
% [mu sigma] = GaussianParamters(x_train);
% [m n] = size(x_train);
% for i = 1:1:m_train
%     temp(i,:) = (x_train(i,:) - mu);
% 
% end
% 
% 
%  inv(sigma);
% %  temp1 =  inv(sigma) *temp;
% %  temp1 = temp' *temp1;
% %  temp1 = temp * inv(sigma);
% %  temp1 = temp1 * temp;
% % p = (2 * pi) ^ (- n_train / 2) * det(Sigma2) ^ (-0.5) * (exp((-0.5) * temp1));
% 
% 
% p = (2 * pi) ^ (- n / 2) * det(sigma) ^ (-0.5) * ...
%     exp(-0.5 * sum(bsxfun(@times, temp * inv(sigma), temp), 2));
